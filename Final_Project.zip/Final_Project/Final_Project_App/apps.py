from django.apps import AppConfig


class FinalProjectAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Final_Project_App'
