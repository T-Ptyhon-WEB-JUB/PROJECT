from dataclasses import field
from math import frexp
from django import forms
from .models import board, task
from django.contrib.auth.forms import UserCreationForm 
from django.contrib.auth.models import User


class boardA(forms.ModelForm):
    class Meta:
        model: board
        fields = '__all__'



        
class taskA(forms.ModelForm):
    class Meta:
        model: task
        fields = ['taskTitle', 'Description']

# class CreateUserForm(UserCreationForm):
#     class Meta:
#         model=User
#         fields=['username','password1','password2']