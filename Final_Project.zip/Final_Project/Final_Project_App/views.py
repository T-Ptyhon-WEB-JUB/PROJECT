from datetime import date
from django.shortcuts import render,resolve_url,redirect
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from .forms import taskA,boardA,UserCreationForm
from .models import task,board
# Signup View Important.

class SignUpView(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy("login")
    template_name = "registration/signup.html"
    

def home(request):
    return render(request,'Final_Project_App/base.html')

def board_view(request):
    boards = board.objects.all()
    return render(request,'Final_Project_App/boards.html',{"boards":boards})
    

def tasks_add(request):
    if (request.method=='POST'):
        a = taskA(request.POST)
        if a.is_valid():
            a.save()
            return redirect(resolve_url("Final_Project_App:home"))
    form = taskA()
    return render(request, 'Final_Project_App/add_task.html',{"form":form})

def tasks_view(request):
    tasks = task.objects.all()
    return render(request,'Final_Project_App/tasks.html',{"tasks":tasks})
