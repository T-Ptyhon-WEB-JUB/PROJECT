from django.db import models
# from django.contrib.auth.models import User

class board(models.Model):
        # user = models.ForeignKey(User,on_delete= models.CASCADE)
        BoardName = models.TextField(max_length=30) # html doc the maxlenght is =30
        description = models.TextField(max_length=2048) # html doc the maxlenght is =2048
        def __str__(self) -> str:
                return self.BoardName


class task(models.Model):
        # board = models.ForeignKey(board,on_delete=models.CASCADE)
        taskTitle = models.TextField(max_length=10) # html doc the maxlenght is =10
        Description = models.TextField(max_length=2048) # html doc the maxlenght is =2048
        #CreatedAt = models.TimeField()
        #DueDate = models.TimeField()
        def __str__(self) -> str:
                return self.taskTitle