from django.urls import path
from . import views
from .views import SignUpView


urlpatterns = [
    path("signup/", SignUpView.as_view(), name="signup"), 
    path('', views.home,name="home"),
    path('boardsView/', views.board_view,name="boardsView"),
    path('tasksView/', views.tasks_view,name="tasksView"),
    path('taskAdd/', views.tasks_add,name="taskAdd"),
    
    
    # this view is IMPORTANT for sign up 
    # DDO NOT DELETE IT 
    
]
